//
//  DrugDetectionApp.swift
//  DrugDetection
//
//  Created by Muhammad Hamzah Robbani on 04/06/25.
//

import SwiftUI

@main
struct DrugDetectionApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
